<?php
	$user = "root";
	$password = "";
	$db_name = "table";
	$host = "localhost";
	$con = mysqli_connect($host,$user,$password,$db_name);
	if($con){
		echo "Connection established.................";
	}else{
		echo "connection failure...............";
	}

	//header('Refresh:10');
	
	$sql = "TRUNCATE table1";
	$con->query($sql);
	$query = mysqli_query($con,$sql);
	if($query){
    		echo "erasing successful..........";
    	}else{
    		echo "erasing error............";
    	}
	

	$file1 = fopen("item1.txt","r");
	while(!feof($file1)){
		$content = fgets($file1);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table1`(`id`,`item_no`,`Food Item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file1);

	
	$sql = "TRUNCATE table2";
	$con->query($sql);
	$query = mysqli_query($con,$sql);
	if($query){
   		echo "erasing successful..........";
   	}else{
   		echo "erasing error............";
   	}

    $file2 = fopen("item2.txt","r");
	while(!feof($file2)){
		$content = fgets($file2);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table2`(`id`,`item_no`,`Food Item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file2);
	
?>