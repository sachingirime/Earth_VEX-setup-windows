<?php

if(isset($_POST["text"])){

$encoded_string = $_POST["text"];
$image_name =$_POST["image_name"];
$decoded_string = base64_decode($encoded_string);

$path = 'img/'.$image_name;

$file = fopen($path, 'wb');


$is_written=fwrite($file,$decoded_string);
fclose($file);

if($is_written >0){
echo "uploaded success";
exit;}
else{
echo "uploaded_failed";
exit;

}
}
?>
