<?php
	$user = "root";
	$password = "";
	$db_name = "";
	$host = "localhost";
	$con = mysqli_connect($host,$user,$password,$db_name);
	if($con){
		echo "Connection established                 ";
	}else{
		echo "connection failure                  ";
	$mysqli = new mysqli($host, $user, $password, $db_name);
	
	$result = $mysqli->query("SELECT id FROM user WHERE id = '1'");
	if($result->num_rows == 0) {
     // row not found, do stuff...
		echo "Data doesnot exist";
	} else {
    // do other stuff...
		echo "Data does exist";
	}
	$mysqli->close();

?>