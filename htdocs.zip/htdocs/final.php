<?php
	$user = "root";
	$password = "";
	$db_name = "app_database";
	$host = "localhost";
	$con = mysqli_connect($host,$user,$password,$db_name);
	if($con){
		echo "Connection established.................";
	}else{
		echo "connection failure...............";
	}

	header('Refresh:1');
	//previous data of table erasing
	$sql = "TRUNCATE table1";
	$con->query($sql);
	$query = mysqli_query($con,$sql);
	
    //next data of table uploading
	$file1 = fopen("img/table1.txt","r");
	while(!feof($file1)){
		$content = fgets($file1);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table1`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file1);

	//previous data of table erasing
	$sql = "TRUNCATE table2";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

   	//next data of table uploading
    $file2 = fopen("img/table2.txt","r");
	while(!feof($file2)){
		$content = fgets($file2);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table2`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file2);

	//previous data of table erasing
	$sql = "TRUNCATE table3";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file3 = fopen("img/table3.txt","r");
	while(!feof($file3)){
		$content = fgets($file3);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table3`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file3);

	//previous data of table erasing
	$sql = "TRUNCATE table4";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file4 = fopen("img/table4.txt","r");
	while(!feof($file4)){
		$content = fgets($file4);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table4`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file4);
	
	//previous data of table erasing
	$sql = "TRUNCATE table5";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file5 = fopen("img/table5.txt","r");
	while(!feof($file5)){
		$content = fgets($file5);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table5`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file5);

	//previous data of table erasing
	$sql = "TRUNCATE table6";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file6 = fopen("img/table6.txt","r");
	while(!feof($file6)){
		$content = fgets($file6);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table6`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file6);

	//previous data of table erasing
	$sql = "TRUNCATE table7";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file7 = fopen("img/table7.txt","r");
	while(!feof($file7)){
		$content = fgets($file7);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table7`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file7);

	//previous data of table erasing
	$sql = "TRUNCATE table8";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file8 = fopen("img/table8.txt","r");
	while(!feof($file8)){
		$content = fgets($file8);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table8`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file8);

	//previous data of table erasing
	$sql = "TRUNCATE table9";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file9 = fopen("img/table9.txt","r");
	while(!feof($file9)){
		$content = fgets($file9);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table9`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file9);

	//previous data of table erasing
	$sql = "TRUNCATE table10";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file10 = fopen("img/table10.txt","r");
	while(!feof($file10)){
		$content = fgets($file10);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table10`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file10);

	//previous data of table erasing
	$sql = "TRUNCATE table11";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file11 = fopen("img/table11.txt","r");
	while(!feof($file11)){
		$content = fgets($file11);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table11`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file11);

	//previous data of table erasing
	$sql = "TRUNCATE table12";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file12 = fopen("img/table12.txt","r");
	while(!feof($file12)){
		$content = fgets($file12);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table12`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file12);

	//previous data of table erasing
	$sql = "TRUNCATE table13";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file13 = fopen("img/table13.txt","r");
	while(!feof($file13)){
		$content = fgets($file13);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table13`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file13);

	//previous data of table erasing
	$sql = "TRUNCATE table14";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file14 = fopen("img/table14.txt","r");
	while(!feof($file14)){
		$content = fgets($file14);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table14`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file14);

	//previous data of table erasing
	$sql = "TRUNCATE table15";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file15 = fopen("img/table15.txt","r");
	while(!feof($file15)){
		$content = fgets($file15);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table15`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file15);

	//previous data of table erasing
	$sql = "TRUNCATE table16";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file16 = fopen("img/table16.txt","r");
	while(!feof($file16)){
		$content = fgets($file16);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table16`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file16);

	//previous data of table erasing
	$sql = "TRUNCATE table17";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file17 = fopen("img/table17.txt","r");
	while(!feof($file17)){
		$content = fgets($file17);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table17`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file17);

	//previous data of table erasing
	$sql = "TRUNCATE table18";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file18 = fopen("img/table18.txt","r");
	while(!feof($file18)){
		$content = fgets($file18);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table18`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file18);

	//previous data of table erasing
	$sql = "TRUNCATE table19";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file19 = fopen("img/table19.txt","r");
	while(!feof($file19)){
		$content = fgets($file19);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table19`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file19);

	//previous data of table erasing
	$sql = "TRUNCATE table20";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	//next data of table uploading
	$file20 = fopen("img/table20.txt","r");
	while(!feof($file20)){
		$content = fgets($file20);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table20`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file20);

	//previous data of table erasing
	$sql = "TRUNCATE table21";
	$con->query($sql);
	$query = mysqli_query($con,$sql);
	
    //next data of table uploading
	$file21 = fopen("img/table21.txt","r");
	while(!feof($file21)){
		$content = fgets($file21);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table21`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file21);

	//previous data of table erasing
	$sql = "TRUNCATE table22";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

    //next data of table uploading
	$file22 = fopen("img/table22.txt","r");
	while(!feof($file22)){
		$content = fgets($file22);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table22`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file22);

	//previous data of table erasing
	$sql = "TRUNCATE table23";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

    //next data of table uploading
	$file22 = fopen("img/table22.txt","r");
	while(!feof($file22)){
		$content = fgets($file22);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table22`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file22);

	//previous data of table erasing
	$sql = "TRUNCATE table23";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	
    //next data of table uploading
	$file23 = fopen("img/table23.txt","r");
	while(!feof($file23)){
		$content = fgets($file23);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table23`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file23);

	//previous data of table erasing
	$sql = "TRUNCATE table24";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	
    //next data of table uploading
	$file24 = fopen("img/table24.txt","r");
	while(!feof($file24)){
		$content = fgets($file24);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table24`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file24);

	//previous data of table erasing
	$sql = "TRUNCATE table25";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	
    //next data of table uploading
	$file25 = fopen("img/table25.txt","r");
	while(!feof($file25)){
		$content = fgets($file25);
		$carray = explode(",",$content);
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table25`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
	}
	fclose($file25);
?>