<?php
	$user = "root";
	$password = "";
	$db_name = "app_database";
	$host = "localhost";

	//header('Refresh:10');

	$con = mysqli_connect($host,$user,$password,$db_name);
	if($con){
		echo "Connection established.................";
	}else{
		echo "connection failure...............";
	}

	//previous data of table erasing
	$sql = "TRUNCATE table14";
	$con->query($sql);
	$query = mysqli_query($con,$sql);

	$file14 = fopen("img/table14.txt","r");
	while(!feof($file14)){
		$content = fgets($file14);
		$carray = explode(",",$content);
		
		list($id,$itemNo,$fname,$quantity) = $carray;
		echo $id.$itemNo.$fname.$quantity;
		
		$sql = "INSERT INTO `table14`(`id`,`item_no`,`food_item`, `Quantity`) VALUES ('$id','$itemNo','$fname','$quantity')";
		$query = mysqli_query($con,$sql);
		
	}
	fclose($file14);

?>