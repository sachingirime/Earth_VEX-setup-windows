<?php    
    //$table_num = $_POST["tNumber"];    
    //$food_item = $_POST["fName"];
    //$item_quantity = $_POST["quantity"];

    $table_num = 1;    
    $food_item = "Chowmein";
    $item_quantity = 5;

    $user = "root";    
    $password = "";    
    $host ="localhost";    
    $db_name ="app_database";    
    $con = mysqli_connect($host,$user,$password,$db_name);


    $sql = "insert into table1 values('".$table_num."','".$food_item."','".$item_quantity."');";   
    /*
    switch($table_num){
        case "1":
           $sql = "insert into table1 values($food_item,$item_quantity);"; 
           echo $sql;
           break;
        case "2":
            $sql = "insert into table2 values($food_item,$item_quantity);"; 
            break;
        case "3":
            $sql = "insert into table3 values($food_item,$item_quantity);"; 
            break;
        default:
            echo "There is no such table"; 
    }
    */

    if(mysqli_query($con,$sql))    
    {   

        echo "Data inserted successfully....";    
    }    
    else     
    {    
        echo "some error occured";    
    }    
    mysqli_close($con);    
    ?> 